<template>
  <div id="exchange">
    <h1>Currency Exchange</h1>
    <div class="conta">
      <div class="contain-one">
        <label for="currency-val">
          <input type="text" class="currency-value" name="currency-val" />
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Exchange",
  components: {},
};
</script>

<style>
</style>