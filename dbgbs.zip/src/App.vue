<template>
  <div id="app">
    <h1>Currency Exchange</h1>
    <h2>Add Your Currency</h2>
    <div class="box-one">
      <label for="currency-add"
        ><h2>Currency Name :</h2>
        <input type="text" class="curn-one" name="Currency-add"
      /></label>
      <label for="cur-val-add"
        ><h2>Currency Value :</h2>
        <input type="text" class="curn-two" name="Currency-val-add"
      /></label>
    </div>
    <a class="add-btn" href="./Exchange.vue">SAVE</a>

    <div class="container">
      <div class="contain-one">
        <label for="val-input">
          <h2>Value to be Exchanged</h2>
          <input type="text" class="one" />
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 5rem;
  height: 150vh;
  font-family: sans-serif;
}

.box-one {
  position: absolute;
  display: inline-block;
  border: 2px solid black;
  width: 50%;
  left: 25%;
  height: 50vh;
}
.box-one h2 {
  padding-right: 20rem;
  padding-top: 5rem;
}

.curn-one {
  color: white;
  position: absolute;
  left: 25rem;
  top: 5.8rem;
  background-color: grey;
}
.curn-two {
  color: white;
  position: absolute;
  left: 25rem;
  top: 13.9rem;
  background-color: grey;
}

.box-one input {
  width: 15rem;
  height: 2rem;
}

.add-btn {
  color: white;
  position: absolute;
  text-align: center;
  top: 30rem;
  left: 61.2%;
  width: 6rem;
  height: 1.35rem;
  background-color: grey;
  text-decoration: none;
}

.container {
  border: 2px solid black;
  position: absolute;
  top: 40rem;
  width: 50%;
  left: 25%;
  height: 50vh;
}

.contain-one h2 {
  position: absolute;
  left: 8%;
  top: 3rem;
}

.contain-one .one {
  position: absolute;
  top: 4.3rem;
}
</style>

#I am sorry i couldnt complete it but really intrested in learning it.