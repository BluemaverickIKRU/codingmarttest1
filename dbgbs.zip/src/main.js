import Vue from "vue";
import App from "./App.vue";
import Exchange from "./Exchange.vue";

Vue.config.productionTip = false;

new Vue({
  render: (h) => h(App, Exchange)
}).$mount("#app", "#exchange");
